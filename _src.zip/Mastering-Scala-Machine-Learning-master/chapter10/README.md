# Advanced Model Monitoring #

## Build & Run ##

```sh
$ cd chapter10
$ ./sbt
> jetty:start
> browse
```

If `browse` doesn't launch your browser, manually open [http://localhost:8080/](http://localhost:8080/) in your browser.
